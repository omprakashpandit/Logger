import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;  

public class XMLFileLog4jExample {

  static Logger logger = Logger.getLogger(XMLFileLog4jExample.class.getName());
  static{
	    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	    System.setProperty("current.date", dateFormat.format(new Date()));
	}
  public static void main(String[] args) {	
	  String userHomeDir = System.getProperty("user.home");
      System.out.println("The User Home Directory is"+ userHomeDir);
      
      
	  String log4jConfigFile = System.getProperty("user.dir") + File.separator + "log4j.xml";
	  DOMConfigurator.configure(log4jConfigFile);
      logger.debug("debug message");  
      logger.info("info message");  
      logger.warn("warn message");  
      logger.error("error message");  
      logger.fatal("fatal message");  
  }
}
